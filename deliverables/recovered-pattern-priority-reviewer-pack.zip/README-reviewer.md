# Independent review: presentation-pattern first batch

This review covers 162 excerpts drawn from 55 provisional
presentation-pattern ideas. Each item states the proposed move in plain words,
so you know what to check. The internal pattern name, category and card ID are
hidden. This is a first check of selected examples, not proof that a move is
common, useful or effective.

## Independence and blinding

Each reviewer must work independently, must not have created these ideas or
their labels, and must not have seen the internal mapping key or another
reviewer's decisions. Do not share completed reviews before both are returned.
In other words, do not have seen the internal mapping key or the other review
before you finish your own.
Use a reviewer code and honestly describe any connection to this project. The
browser records your statement; it cannot verify your independence.

## Review

Open `recovered-pattern-priority-review.html` in a browser. For each item,
compare the excerpt with the proposed move. Open the source and read more of the
surrounding transcript or video when possible. Record what the speaker is
doing, another plausible explanation, relevant context, any source or access
concern, and what remains uncertain. If the excerpt does not show the move,
say what it does instead. If you cannot tell, choose that option; do not guess.
You may leave items blank. A blank answer stays missing; it is never counted as
agreement.

The six choices mean: the excerpt shows the proposed move; the speaker is doing
something else; the context is too limited; you are unsure for another reason;
the speaker/source may be wrong; or the clip may be a duplicate or compilation.
Each item says whether its transcript came from the linked video, another
video source, or an outside transcript. Machine-made transcripts can be wrong,
so check the linked recording where possible.

Download the JSON export and return it unchanged. Do not add candidate labels or
merge it with another review. Keep your working copy private until both
independent reviews have been returned.

## Return validation (for the coordinator)

From the project repository, run:

```text
python3 scripts/validate_recovered_pattern_priority_review_export.py reviewer.json
```

After two independent returns validate, compare them and route observed
disagreements to adjudication using the commands in
`writeups/next-validation-runbook.md`. Preserve all exports, missing responses,
comparison, and adjudication as separate records. Review agreement or
adjudication does not establish recurrence, teachability, audience outcomes,
or effectiveness.
