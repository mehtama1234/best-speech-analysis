# The Speaking Patterns Fieldbook

Unzip the complete folder, then open writeups/speaking-patterns-fieldbook.html
in a browser. It runs offline without an installation or an account. Keep the
writeups folder intact so the linked source analyses remain available.

The PDF is a paginated reading edition. Use the HTML edition for linked source
documents and interactive cards. The Markdown file is the editable manuscript.
This package contains two guides. The fieldbook has seven chapters, 22 main
themes, 18 smaller speaking moves, 15 more ideas to explore, a full sample
presentation and 55 made-up before-and-after examples. It uses 17 selected
transcript analyses from a larger project that has reviewed the full transcripts
of 395 videos in a 480-video inventory; it does not recheck all 395. The companion book
has 27 practice chapters and 11 learning paths. Open the
companion HTML from `writeups/companion/speaking-practice.html`; keep its CSS
file beside it. `writeups/cross-repo-communication-source-map.md` shows which
speech, coaching, storytelling, comedy and polished-talk sources are connected
to which companion chapters. `writeups/companion/sources.json` is the
companion's portable source index. The package does not include audio, video or photographs.

The 55 patterns are ideas noticed in transcript searches. Other reviewers have
not checked them, and no audience study has tested them. A 162-item review set
is ready, but this package contains no reviewer answers. Read
writeups/fieldbook-editorial-handoff.md for details. The speakers and named
organizations do not endorse this book. This package does not claim permission
for other uses of the source material.
